# yuanyuantao.com

Academic personal website for Dr. Yuanyuan Tao, designed for GitHub Pages.

## Deploy
1. Create a public GitHub repository named `<YOUR-GITHUB-USERNAME>.github.io`.
2. Upload the contents of this folder.
3. In Settings → Pages, select the deployment source.
4. Set the custom domain to `yuanyuantao.com`.
5. Configure DNS for the domain according to GitHub Pages documentation.

Replace `portrait` with the official profile photo and add `cv.pdf` before publishing if desired.
